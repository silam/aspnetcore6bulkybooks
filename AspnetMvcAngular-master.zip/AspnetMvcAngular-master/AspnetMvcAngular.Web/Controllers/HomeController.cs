﻿using System.Web.Mvc;

namespace AspnetMvcAngular.Web.Controllers {
    public class HomeController : Controller {
        public ActionResult Index() {
            return View();
        }
    }
}