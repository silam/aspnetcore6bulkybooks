![DrinkBird Logo](http://blog.drinkbird.com/assets/media/db.png)

# Code from the "Blending ASP.NET MVC with Angular" post series

* [Building Angular templates with Razor](http://blog.drinkbird.com/aspnet-mvc-angular-razor-templates/)