# azurepaasmicroservices
A semi realistic solution with code that demonstrates how to use Azure PaaS to develop a Microservices architecture using Web Apps, Azure Functions, Logic Apps, Service Bus and Azure Tables.

After you clone the repository and open the solution make sure you:

1. Update the NuGet packages
2. Create your own Azure resources and use your own connection strings and app settings.
